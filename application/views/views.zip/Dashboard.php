<section class="content">
	<div class="container-fluid">
		<br>
		<div class="row">
			<div class="col-md-12">
				<!-- Presentase Berdasarkan Status -->
				<div class="card">
					<div class="card-body text-center">
						<h3> Selamat Datang </h3>
					</div>
				</div>
			</div>
		</div>

		<div class="row">
			<div class="col-md-6">
				<!-- Presentase Berdasarkan Status -->
				<div class="card">
					<div class="card-body text-center">
						A
					</div>
				</div>
			</div>

			<div class="col-md-6">
				<!-- Presentase Berdasarkan Status -->
				<div class="card">
					<div class="card-body text-center">
						b
					</div>
				</div>
			</div>
		</div>


	</div>
</section>