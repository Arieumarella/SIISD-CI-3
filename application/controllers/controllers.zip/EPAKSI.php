<?php
defined('BASEPATH') OR exit('No direct script access allowed');

use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpWord\PhpWord;
use PhpOffice\PhpWord\Writer\Word2007;
use PhpOffice\PhpWord\Table;

class EPAKSI extends CI_Controller {

	public function __construct() {
		parent:: __construct();
		if ($this->session->userdata('sts_login') != true) {

			$this->session->set_flashdata('psn', '<div class="alert alert-danger alert-dismissible fade show text-center" style="font-size:15px;" role="alert">
				Anda belum login / Sesi anda telah habis.!
				<button type="button" class="close" data-dismiss="alert" aria-label="Close">
				<span aria-hidden="true">&times;</span>
				</button>
				</div>');

			redirect('/Login', 'refresh');
			return;
		}

		$this->load->model('M_dinamis');
		$this->load->model('M_Epaksi');
	}


	public function index()
	{

		$tmp = array(
			'tittle' => 'Form 8',
			'footer_content' => 'footer_content',
			'NavbarTop' => 'NavbarTop',
			'NavbarLeft' => 'NavbarLeft',
			'prov' => ($this->session->userdata('prive') != 'balai') ? $this->M_dinamis->add_all('m_prov', '*', 'provid', 'asc') : $this->M_Epaksi->getProvBalai(),
			'content' => 'Form8/8'
		);

		$this->load->view('tamplate/baseTamplate', $tmp);
	}


	public function getDataTable()
	{
		$jumlahDataPerHalaman  = ($this->input->post('perhalaman')) ? $this->input->post('perhalaman') : 5;
		$halamanSaatIni  = ($this->input->post('halamanSaatIni')) ? $this->input->post('halamanSaatIni') : 1;
		$search = ($this->input->post('search') != '') ? $this->input->post('search') : null; 
		$provid = ($this->input->post('provid') != '') ? $this->input->post('provid') : null;
		$kotakabid = ($this->input->post('kotakabid') != '') ? $this->input->post('kotakabid') : null;

		if ($this->session->userdata('prive') == 'pemda' or $this->session->userdata('prive') == 'provinsi') {
			$kotakabid = $this->session->userdata('kotakabid');
		}


		$offset = ($halamanSaatIni - 1) * $jumlahDataPerHalaman;

		$data = $this->M_Epaksi->getDataTable($jumlahDataPerHalaman, $search, $offset, $provid, $kotakabid);


		echo json_encode(['code' => ($data != false) ? 200 : 401, 'data' => ($data != false) ? $data['data'] : '', 'jml_data' => ($data != false) ? $data['jml_data'] : '']);


	}


	public function getDi()
	{
		$searchDi = $this->input->post('searchDi');
		$kdprov = $this->input->post('kdprov');
		$kdKab = $this->input->post('kdKab');

		$data = $this->M_Epaksi->getDataDi($searchDi, $kdprov, $kdKab);

		echo json_encode(['code' => ($data) ? 200 : 401, 'data' => $data]);

	}


	public function getDataKabKota()
	{
		$prov = $this->input->post('prov');

		if ($this->session->userdata('prive') != 'balai') {
			$data = $this->M_dinamis->getResult('m_kotakab', ['provid' => $prov]);
		}else{
			$data = $this->M_Epaksi->getkabKota($prov);
		}

		echo json_encode($data);

	}


	public function TambahData()
	{

		$kotakabid = $this->session->userdata('kotakabid');

		$tmp = array(
			'tittle' => 'Tambah Data Form 8',
			'dataDi' => ($this->session->userdata('prive') != 'admin') ? $this->M_dinamis->getResult('m_irigasi', ['kotakabid' => $kotakabid, 'isActive' => '1']) : null,
		);

		$this->load->view('Form8/tambaData', $tmp);
	}

	public function getDiTambahData()
	{
		$searchDi = $this->input->post('searchDi');

		$data = $this->M_Epaksi->getDataDiTambah($searchDi);

		echo json_encode(['code' => ($data) ? 200 : 401, 'data' => $data]);

	}


	public function SimpanData()
	{

		$irigasiid  = ubahKomaMenjadiTitik($this->input->post('irigasiid'));
		$laPermen = ubahKomaMenjadiTitik($this->input->post('laPermen'));
		

		$dataM_irigasi = $this->M_dinamis->getById('m_irigasi', ['irigasiid' => $irigasiid, 'isActive' => '1']);

		$dataInsert = array(
			'ta' => $this->session->userdata('thang'),
			'provid' => $dataM_irigasi->provid,
			'kotakabid' => $dataM_irigasi->kotakabid,
			'irigasiid' => $irigasiid,
			'laPermen' => $laPermen,			
			'uidIn' => $this->session->userdata('uid'),
			'uidDt' => date('Y-m-d H:i:s')
		);

		$pros = $this->M_Epaksi->save($dataInsert, $irigasiid);

		if ($pros == true) {
			$this->session->set_flashdata('psn', '<div class="alert alert-success alert-dismissible">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
				<h5><i class="icon fas fa-check"></i> Berhasil.!</h5>
				Data Berhasil Disimpan.!
				</div>');
		}else{

			$this->session->set_flashdata('psn', '<div class="alert alert-danger alert-dismissible">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
				<h5><i class="icon fas fa-ban"></i> Gagal.!</h5>
				Data Gagal Disimpan.
				</div>');
		}

		redirect('/EPAKSI', 'refresh');

	}


	public function getDetailData($id=null)
	{
		$tmp = array(
			'tittle' => 'Detail Data Form 8',
			'dataDi' => $this->M_Epaksi->getDataDiById($id),
			'dataBody' => $this->M_Epaksi->getDataBody($id)
		);

		$this->load->view('Form8/detail', $tmp);
	}


	public function delete()
	{
		$id = $this->input->post('id');

		$pros = $this->M_dinamis->delete('p_f8', ['id' => $id]);
		$pros = $this->M_dinamis->delete('p_f8_pelaksana', ['idF8' => $id]);

		if ($pros) {
			$this->session->set_flashdata('psn', '<div class="alert alert-success alert-dismissible">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
				<h5><i class="icon fas fa-check"></i> Berhasil.!</h5>
				Data Berhasil Dihapus.!
				</div>');
		}else{

			$this->session->set_flashdata('psn', '<div class="alert alert-danger alert-dismissible">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
				<h5><i class="icon fas fa-ban"></i> Gagal.!</h5>
				Data Gagal Dihapus.
				</div>');
		}

		echo json_encode(['code' => 200]);
	}


	public function editData($id=null)
	{
		$tmp = array(
			'tittle' => 'Edit Data Form 8',
			'dataDi' => $this->M_Epaksi->getDataDiById($id),
			'dataBody' => $this->M_Epaksi->getDataBody($id),
			'id' => $id
		);

		$this->load->view('Form8/formEdit', $tmp);
	}

	public function SimpanDataEdit()
	{
		$idEdit = ubahKomaMenjadiTitik($this->input->post('idEdit'));

		$laPermen = ubahKomaMenjadiTitik($this->input->post('laPermen'));
		
		$dataInsert = array(
			'laPermen' => $laPermen,			
			'uidInUp' => $this->session->userdata('uid'),
			'uidDtUp' => date('Y-m-d H:i:s')
		);

		$pros = $this->M_Epaksi->update($dataInsert, $idEdit);

		if ($pros == true) {
			$this->session->set_flashdata('psn', '<div class="alert alert-success alert-dismissible">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
				<h5><i class="icon fas fa-check"></i> Berhasil.!</h5>
				Data Berhasil Disimpan.!
				</div>');
		}else{

			$this->session->set_flashdata('psn', '<div class="alert alert-danger alert-dismissible">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
				<h5><i class="icon fas fa-ban"></i> Gagal.!</h5>
				Data Gagal Disimpan.
				</div>');
		}

		redirect("/EPAKSI", 'refresh');

	}


	public function formExcel()
	{
		$tmp = array(
			'tittle' => 'Format Excel 1F',
			'dataProv' => $this->M_dinamis->add_all('m_prov', '*', 'provid', 'asc')
		);

		$this->load->view('EPAKSI/excelF1', $tmp);
	}


	public function downloadExcel()
	{
		$prov = $this->input->post('prov');
		$kab = ($this->session->userdata('prive') == 'admin') ? $this->input->post('kab') : $this->session->userdata('kotakabid');
		$thang = $this->session->userdata('thang');

		$menitDetik = date('i').date('s');

		copy('./assets/format/F1.xlsx', "./assets/format/tmp/$menitDetik.xlsx");

		$path = "./assets/format/tmp/$menitDetik.xlsx";
		$spreadsheet = IOFactory::load($path);

		$cek = $this->M_dinamis->getById('p_f7', ['kotakabid' => $kab, 'ta' => $thang]);

		if ($cek) {
			$data = $this->M_Epaksi->getDataDiFull($thang, $kab);
		}else{
			$thang = $thang-1;
			$data = $this->M_Epaksi->getDataDiFull((string)$thang, $kab);
		}

		$indexLopp = 5;
		$nilaiAwal = 1;

		foreach ($data as $key => $val) {

			$spreadsheet->getActiveSheet()->getCell("A$indexLopp")->setValue($val->provIdX);
			$spreadsheet->getActiveSheet()->getCell("B$indexLopp")->setValue($val->kotakabidX);
			$spreadsheet->getActiveSheet()->getCell("C$indexLopp")->setValue($val->irigasiidX);
			$spreadsheet->getActiveSheet()->getCell("D$indexLopp")->setValue($nilaiAwal);
			$spreadsheet->getActiveSheet()->getCell("E$indexLopp")->setValue($val->provinsi);
			$spreadsheet->getActiveSheet()->getCell("F$indexLopp")->setValue($val->kemendagri);
			$spreadsheet->getActiveSheet()->getCell("G$indexLopp")->setValue($val->nama);
			$spreadsheet->getActiveSheet()->getCell("H$indexLopp")->setValue($val->laPermen);
			$spreadsheet->getActiveSheet()->getCell("I$indexLopp")->setValue($val->tkpaiInvAsetIrigasiThn);
			$spreadsheet->getActiveSheet()->getCell("J$indexLopp")->setValue($val->tkpaiInvAsetIrigasiPsen);
			$spreadsheet->getActiveSheet()->getCell("K$indexLopp")->setValue($val->tkpaiPerencanaanPAIThn);
			$spreadsheet->getActiveSheet()->getCell("L$indexLopp")->setValue($val->tkpaiPerencanaanPAIPsen);
			$spreadsheet->getActiveSheet()->getCell("M$indexLopp")->setValue($val->tkpaiPelaksanaanPAIThn);
			$spreadsheet->getActiveSheet()->getCell("N$indexLopp")->setValue($val->tkpaiPelaksanaanPAIPsen);
			$spreadsheet->getActiveSheet()->getCell("O$indexLopp")->setValue($val->tkpaiEvaluasiPAIThn);
			$spreadsheet->getActiveSheet()->getCell("P$indexLopp")->setValue($val->tkpaiEvaluasiPAIPsen);
			$spreadsheet->getActiveSheet()->getCell("Q$indexLopp")->setValue($val->tkpaiPethirHasilInventAIThn);
			$spreadsheet->getActiveSheet()->getCell("R$indexLopp")->setValue($val->tkpaiPethirHasilInventAIPsen);
			$spreadsheet->getActiveSheet()->getCell("S$indexLopp")->setValue($val->keterangan);


			$nilaiAwal++;
			$indexLopp++;
		}

		
		if (ob_get_contents()) {
			ob_end_clean();
		}


		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment; filename="export 1F.xlsx"');  
		header('Cache-Control: max-age=0');
		$writer = new Xlsx($spreadsheet);
		$writer->save('php://output');
		unlink("./assets/format/tmp/$menitDetik.xlsx");

	}


	public function prosesUploadExcel()
	{

		$prov = ($this->session->userdata('prive') == 'admin') ? $this->input->post('prov-upload') : $this->session->userdata('provid'); 
		$kab = ($this->session->userdata('prive') == 'admin') ? $this->input->post('kab-upload') : $this->session->userdata('kotakabid');

		if ($kab == null or $kab == '') {

			$this->session->set_flashdata('psn', '<div class="alert alert-danger alert-dismissible">
				<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
				<h5><i class="icon fas fa-ban"></i> Gagal.!</h5>
				Silakan Pilih Provinsi dan Kabupaten/kota Terlebih Dahulu.
				</div>');

			redirect("/EPAKSI/formExcel", 'refresh');
		}

		$nmProv = getProvByKotaKabId($kab);
		$nmKab = getKabKota($kab);

		$config['allowed_types'] = 'xlsx';
		$config['file_name'] = 'upload_time_'.date('Y-m-d').'_'.time().'.xlsx';
		$config['max_size'] = 50000;

		$this->load->library('upload', $config);

		if (!empty($_FILES['fileExcel']['name'])) {

			if (!file_exists('assets/upload_file')) {
				mkdir('assets/upload_file');
			}

			if (!file_exists('assets/upload_file/F1')) {
				mkdir('assets/upload_file/F1');
			}

			if (!file_exists("assets/upload_file/F1/$nmProv")) {
				mkdir("assets/upload_file/F1/$nmProv");
			}

			if (!file_exists("assets/upload_file/F1/$nmProv/$nmKab")) {
				mkdir("assets/upload_file/F1/$nmProv/$nmKab");
			}

			$path = "assets/upload_file/F1/$nmProv/$nmKab/";

			$pathX = $_FILES['fileExcel']['name'];
			$ext = pathinfo($pathX, PATHINFO_EXTENSION);

			$config['upload_path'] = $path;
			$config['allowed_types'] = 'xlsx';
			$config['file_name'] = 'upload_time_'.date('Y-m-d').'_'.time().'.'.$ext;
			$config['max_size'] = 200000;

			$this->upload->initialize($config);

			if (!$this->upload->do_upload('fileExcel')){

				$this->session->set_flashdata('psn', "<div class='alert alert-danger alert-dismissible'>
					<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>×</button>
					<h5><i class='icon fas fa-ban'></i> Gagal.!</h5>
					Dokumen Gagal diUpload Karena $psnError
					</div>");

				redirect("/EPAKSI/formExcel", 'refresh');

			}else{

				$upload_data = $this->upload->data();
				$namaFile = $upload_data['file_name'];
				$fullPath = $upload_data['full_path'];
				$kotakabidX = '';

				$filePath = "assets/upload_file/F1/$nmProv/$nmKab/$namaFile";

				$spreadsheet = IOFactory::load($filePath);

				$sheetX = $spreadsheet->getActiveSheet();
				$ValA1 = $sheetX->getCell('A1')->getValue();
				$ValB1 = $sheetX->getCell('B1')->getValue();
				$ValC1 = $sheetX->getCell('C1')->getValue();
				$S4 = $sheetX->getCell('S4')->getValue();


				if ($ValA1 != 'provid' or $ValB1 != 'kotakabid' or $ValC1 != 'irigasiid' or $S4 != '16') {

					$this->session->set_flashdata('psn', '<div class="alert alert-danger alert-dismissible">
						<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
						<h5><i class="icon fas fa-ban"></i> Gagal.!</h5>
						Format Dokumen Tidak Sesuai.
						</div>');

					redirect("/EPAKSI/formExcel", 'refresh');

				}


				$sheetCount = $spreadsheet->getSheetCount();

				$baseArray = [];

				for ($i = 0; $i < $sheetCount; $i++) {
					$sheet = $spreadsheet->getSheet($i);

					$highestRow = $sheet->getHighestRow(); 
					$highestColumn = $sheet->getHighestColumn(); 

					for ($row = 5; $row <= $highestRow; $row++) { 
						$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, NULL, TRUE, FALSE);

						$kotakabidX = ubahKomaMenjadiTitik($rowData[0][1]);

						$arrayRow = array(
							'ta' => $this->session->userdata('thang'),
							'provid' => ubahKomaMenjadiTitik($rowData[0][0]),
							'kotakabid' => ubahKomaMenjadiTitik($rowData[0][1]),
							'irigasiid' => ubahKomaMenjadiTitik($rowData[0][2]),
							'laPermen' => ubahKomaMenjadiTitik($rowData[0][7]),
							'tkpaiInvAsetIrigasiThn' => ubahKomaMenjadiTitik($rowData[0][8]),
							'tkpaiInvAsetIrigasiPsen' => ubahKomaMenjadiTitik($rowData[0][9]),
							'tkpaiPerencanaanPAIThn' => ubahKomaMenjadiTitik($rowData[0][10]),
							'tkpaiPerencanaanPAIPsen' => ubahKomaMenjadiTitik($rowData[0][11]),
							'tkpaiPelaksanaanPAIThn' => ubahKomaMenjadiTitik($rowData[0][12]),
							'tkpaiPelaksanaanPAIPsen' => ubahKomaMenjadiTitik($rowData[0][13]),
							'tkpaiEvaluasiPAIThn' => ubahKomaMenjadiTitik($rowData[0][14]),
							'tkpaiEvaluasiPAIPsen' => ubahKomaMenjadiTitik($rowData[0][15]),
							'tkpaiPethirHasilInventAIThn' => ubahKomaMenjadiTitik($rowData[0][16]),
							'tkpaiPethirHasilInventAIPsen' => ubahKomaMenjadiTitik($rowData[0][17]),
							'keterangan' => ubahKomaMenjadiTitik($rowData[0][18]),
							'uidIn' => $this->session->userdata('uid'),
							'uidDt' => date('Y-m-d H:i:s')
						);

						$baseArray[] = $arrayRow;

					}
				}

				$thang = $this->session->userdata('thang');

				$this->M_dinamis->delete('p_f7', ['kotakabid' => $kotakabidX, 'ta' => $thang]);
				$pros = $this->M_dinamis->insertBatch('p_f7', $baseArray);

				if ($pros == true) {
					$this->session->set_flashdata('psn', '<div class="alert alert-success alert-dismissible">
						<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
						<h5><i class="icon fas fa-check"></i> Berhasil.!</h5>
						Data Berhasil Disimpan.!
						</div>');
				}else{

					$this->session->set_flashdata('psn', '<div class="alert alert-danger alert-dismissible">
						<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
						<h5><i class="icon fas fa-ban"></i> Gagal.!</h5>
						Data Gagal Disimpan.
						</div>');
				}

				redirect("/EPAKSI/formExcel", 'refresh');

			}


		}

	}



	public function downloadTabel($kotakabid=null)
	{
		$prive = $this->session->userdata('prive');
		$thang = $this->session->userdata('thang');

		if ($kotakabid==null) {
			
			if ($prive != 'admin' and $prive != 'pemda') {

				$this->session->set_flashdata('psn', '<div class="alert alert-danger alert-dismissible">
					<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
					<h5><i class="icon fas fa-ban"></i> Gagal.!</h5>
					Roll Anda Tidak Dibolehkan.
					</div>');

				redirect("/EPAKSI", 'refresh');
				return;
			}

		}

		
		$data = $this->M_Epaksi->getDataDownload($thang, $prive, $kotakabid);

		$menitDetik = date('i').date('s');

		copy('./assets/format/downladBase/epaksi.xlsx', "./assets/format/tmp/$menitDetik.xlsx");

		$path = "./assets/format/tmp/$menitDetik.xlsx";
		$spreadsheet = IOFactory::load($path);
		$indexLopp = 6;
		$nilaiAwal = 1;

		$ta = $this->session->userdata('thang');
		$tahunAwal = intval($ta);
		$data5Tahun = array();

		for ($i = 0; $i < 5; $i++) {
			$tahun = $tahunAwal - $i;
			$data5Tahun[] = $tahun;
		}


		$spreadsheet->getActiveSheet()->getCell("F2")->setValue($data5Tahun[4]);
		$spreadsheet->getActiveSheet()->getCell("L2")->setValue($data5Tahun[3]);
		$spreadsheet->getActiveSheet()->getCell("R2")->setValue($data5Tahun[2]);
		$spreadsheet->getActiveSheet()->getCell("X2")->setValue($data5Tahun[1]);
		$spreadsheet->getActiveSheet()->getCell("AD2")->setValue($data5Tahun[0]);
		
		foreach ($data as $key => $val) {
			
			$spreadsheet->getActiveSheet()->getCell("A$indexLopp")->setValue($nilaiAwal);
			$spreadsheet->getActiveSheet()->getCell("B$indexLopp")->setValue($val->provinsi);
			$spreadsheet->getActiveSheet()->getCell("C$indexLopp")->setValue($val->kemendagri);
			$spreadsheet->getActiveSheet()->getCell("D$indexLopp")->setValue($val->nama);
			$spreadsheet->getActiveSheet()->getCell("E$indexLopp")->setValue($val->laPermen);
			$spreadsheet->getActiveSheet()->getCell("F$indexLopp")->setValue($val->tahunPlaksana1);
			$spreadsheet->getActiveSheet()->getCell("G$indexLopp")->setValue($val->stKontrak1 == 'k' ? 'Kontraktual' : 'Swakelola');
			$spreadsheet->getActiveSheet()->getCell("H$indexLopp")->setValue($val->namaKonsultan1);
			$spreadsheet->getActiveSheet()->getCell("I$indexLopp")->setValue($val->nomorKontrak1);
			$spreadsheet->getActiveSheet()->getCell("J$indexLopp")->setValue($val->tanggalKontrak1);
			$spreadsheet->getActiveSheet()->getCell("K$indexLopp")->setValue($val->lamaPelaksanaan1);
			$spreadsheet->getActiveSheet()->getCell("L$indexLopp")->setValue($val->tahunPlaksana2);
			$spreadsheet->getActiveSheet()->getCell("M$indexLopp")->setValue($val->stKontrak2 == 'k' ? 'Kontraktual' : 'Swakelola');
			$spreadsheet->getActiveSheet()->getCell("N$indexLopp")->setValue($val->namaKonsultan2);
			$spreadsheet->getActiveSheet()->getCell("O$indexLopp")->setValue($val->nomorKontrak2);
			$spreadsheet->getActiveSheet()->getCell("P$indexLopp")->setValue($val->tanggalKontrak2);
			$spreadsheet->getActiveSheet()->getCell("Q$indexLopp")->setValue($val->lamaPelaksanaan2);
			$spreadsheet->getActiveSheet()->getCell("R$indexLopp")->setValue($val->tahunPlaksana3);
			$spreadsheet->getActiveSheet()->getCell("S$indexLopp")->setValue($val->stKontrak3 == 'k' ? 'Kontraktual' : 'Swakelola');
			$spreadsheet->getActiveSheet()->getCell("T$indexLopp")->setValue($val->namaKonsultan3);
			$spreadsheet->getActiveSheet()->getCell("U$indexLopp")->setValue($val->nomorKontrak3);
			$spreadsheet->getActiveSheet()->getCell("V$indexLopp")->setValue($val->tanggalKontrak3);
			$spreadsheet->getActiveSheet()->getCell("W$indexLopp")->setValue($val->lamaPelaksanaan3);
			$spreadsheet->getActiveSheet()->getCell("X$indexLopp")->setValue($val->tahunPlaksana4);
			$spreadsheet->getActiveSheet()->getCell("Y$indexLopp")->setValue($val->stKontrak4 == 'k' ? 'Kontraktual' : 'Swakelola');
			$spreadsheet->getActiveSheet()->getCell("Z$indexLopp")->setValue($val->namaKonsultan4);
			$spreadsheet->getActiveSheet()->getCell("AA$indexLopp")->setValue($val->nomorKontrak4);
			$spreadsheet->getActiveSheet()->getCell("AB$indexLopp")->setValue($val->tanggalKontrak4);
			$spreadsheet->getActiveSheet()->getCell("AC$indexLopp")->setValue($val->lamaPelaksanaan4);
			$spreadsheet->getActiveSheet()->getCell("AD$indexLopp")->setValue($val->tahunPlaksana5);
			$spreadsheet->getActiveSheet()->getCell("AE$indexLopp")->setValue($val->stKontrak5 == 'k' ? 'Kontraktual' : 'Swakelola');
			$spreadsheet->getActiveSheet()->getCell("AF$indexLopp")->setValue($val->namaKonsultan5);
			$spreadsheet->getActiveSheet()->getCell("AG$indexLopp")->setValue($val->nomorKontrak5);
			$spreadsheet->getActiveSheet()->getCell("AH$indexLopp")->setValue($val->tanggalKontrak5);
			$spreadsheet->getActiveSheet()->getCell("AI$indexLopp")->setValue($val->lamaPelaksanaan5);

			$nilaiAwal++;
			$indexLopp++;
		}

		
		if (ob_get_contents()) {
			ob_end_clean();
		}


		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment; filename="epaksi.xlsx"');  
		header('Cache-Control: max-age=0');
		$writer = new Xlsx($spreadsheet);
		$writer->save('php://output');
		unlink("./assets/format/tmp/$menitDetik.xlsx");
		

		
	}


}